import { Link } from "react-router-dom";
import { Phone, Mail, MapPin, Clock, Globe, Shield } from "lucide-react";
import { Logo, LogoMark } from "./logo";
import { SimpleSocialFooter } from "./simple-social-footer";
import ShipNexaLogo from "./shipnexa-logo";

export function Footer() {
  return (
    <footer className="bg-shipblue-900 text-white">
      {/* Main Footer Content */}
      <div className="container mx-auto px-4 py-16">
        <div className="grid lg:grid-cols-4 md:grid-cols-2 gap-12">
          {/* Company Info */}
          <div className="lg:col-span-1">
            <div className="mb-6">
              <ShipNexaLogo size="lg" variant="full" className="" />
            </div>
            <p className="text-gray-300 mb-6 leading-relaxed">
              ShipNexa.it - Your next-generation logistics partner. We deliver
              innovative, fast, and secure shipping solutions across Italy and
              worldwide with advanced real-time tracking technology.
            </p>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Globe className="h-5 w-5 text-orange-500" />
                <span className="text-sm text-gray-300">120+ Countries</span>
              </div>
              <div className="flex items-center space-x-2">
                <Shield className="h-5 w-5 text-orange-500" />
                <span className="text-sm text-gray-300">Fully Insured</span>
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold mb-6 text-orange-500">
              Quick Links
            </h3>
            <ul className="space-y-3">
              <li>
                <Link
                  to="/track"
                  className="text-gray-300 hover:text-white transition-colors duration-200"
                >
                  Track Package
                </Link>
              </li>
              <li>
                <Link
                  to="/services"
                  className="text-gray-300 hover:text-white transition-colors duration-200"
                >
                  Our Services
                </Link>
              </li>
              <li>
                <Link
                  to="/gallery"
                  className="text-gray-300 hover:text-white transition-colors duration-200"
                >
                  Gallery
                </Link>
              </li>
              <li>
                <Link
                  to="/about"
                  className="text-gray-300 hover:text-white transition-colors duration-200"
                >
                  About Us
                </Link>
              </li>
              <li>
                <Link
                  to="/contact"
                  className="text-gray-300 hover:text-white transition-colors duration-200"
                >
                  Contact
                </Link>
              </li>
              <li>
                <Link
                  to="/newspaper"
                  className="text-gray-300 hover:text-white transition-colors duration-200"
                >
                  News & Updates
                </Link>
              </li>
            </ul>
          </div>

          {/* Services */}
          <div>
            <h3 className="text-lg font-semibold mb-6 text-orange-500">
              Services
            </h3>
            <ul className="space-y-3">
              <li className="text-gray-300">Air Freight</li>
              <li className="text-gray-300">Ocean Freight</li>
              <li className="text-gray-300">Ground Transport</li>
              <li className="text-gray-300">Express Delivery</li>
              <li className="text-gray-300">Customs Clearance</li>
              <li className="text-gray-300">Warehousing</li>
            </ul>
          </div>

          {/* Contact & Social Media Section */}
          <div>
            <h3 className="text-lg font-semibold mb-6 text-orange-500">
              Contact Info
            </h3>
            <div className="space-y-4 mb-8">
              <div className="flex items-center space-x-3">
                <Phone className="h-4 w-4 text-orange-500 flex-shrink-0" />
                <span className="text-gray-300 text-sm">+39 351 123 4567</span>
              </div>
              <div className="flex items-center space-x-3">
                <Mail className="h-4 w-4 text-orange-500 flex-shrink-0" />
                <span className="text-gray-300 text-sm">info@shipnexa.it</span>
              </div>
              <div className="flex items-start space-x-3">
                <MapPin className="h-4 w-4 text-orange-500 flex-shrink-0 mt-0.5" />
                <span className="text-gray-300 text-sm leading-relaxed">
                  Via Roma 123
                  <br />
                  20121 Milano, Italy
                </span>
              </div>
              <div className="flex items-center space-x-3">
                <Clock className="h-4 w-4 text-orange-500 flex-shrink-0" />
                <span className="text-gray-300 text-sm">
                  24/7 Customer Support
                </span>
              </div>
            </div>
            <SimpleSocialFooter className="" />
          </div>
        </div>
      </div>

      {/* Bottom Footer */}
      <div className="border-t border-shipblue-800">
        <div className="container mx-auto px-4 py-6">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="text-gray-400 text-sm mb-4 md:mb-0">
              © 2024 ShipNexa.it. All rights reserved.
            </div>
            <div className="flex space-x-6 text-sm">
              <Link
                to="/privacy"
                className="text-gray-400 hover:text-white transition-colors duration-200"
              >
                Privacy Policy
              </Link>
              <Link
                to="/terms"
                className="text-gray-400 hover:text-white transition-colors duration-200"
              >
                Terms of Service
              </Link>
              <Link
                to="/security"
                className="text-gray-400 hover:text-white transition-colors duration-200"
              >
                Security
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
