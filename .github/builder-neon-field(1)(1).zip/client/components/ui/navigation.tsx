import { Link, useLocation } from "react-router-dom";
import { Menu, X } from "lucide-react";
import { Button } from "./button";
import { useState } from "react";
import { GetQuoteModal } from "./get-quote-modal";
import { Logo, LogoMark } from "./logo";
import ShipNexaLogo from "./shipnexa-logo";

export function Navigation() {
  const location = useLocation();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isQuoteModalOpen, setIsQuoteModalOpen] = useState(false);

  const navItems = [
    { href: "/", label: "Home" },
    { href: "/track", label: "Track Package" },
    { href: "/services", label: "Services" },
    { href: "/gallery", label: "Gallery" },
    { href: "/about", label: "About Us" },
    { href: "/contact", label: "Contact" },
  ];

  return (
    <nav className="bg-white shadow-lg sticky top-0 z-50 border-b border-gray-100">
      {/* Main Navigation */}
      <div className="container mx-auto px-4 lg:px-6">
        <div className="flex justify-between items-center py-3 lg:py-4">
          {/* Logo */}
          <Link
            to="/"
            className="flex items-center transition-transform hover:scale-105"
          >
            <ShipNexaLogo size="lg" variant="full" />
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center space-x-6 xl:space-x-8">
            {navItems.map((item) => (
              <Link
                key={item.href}
                to={item.href}
                className={`font-medium text-sm xl:text-base transition-all duration-200 hover:text-shipblue-600 py-2 px-3 rounded-md focus:outline-none focus:ring-2 focus:ring-shipblue-500 focus:ring-offset-2 ${
                  location.pathname === item.href
                    ? "text-shipblue-600 border-b-2 border-shipblue-600"
                    : "text-gray-700 hover:text-shipblue-600"
                }`}
              >
                {item.label}
              </Link>
            ))}
            <div className="flex items-center space-x-3 ml-6">
              <Link to="/auth">
                <Button
                  variant="outline"
                  size="sm"
                  className="border-shipblue-600 text-shipblue-600 hover:bg-shipblue-600 hover:text-white transition-all duration-300 px-6"
                >
                  Login
                </Button>
              </Link>
              <Button
                onClick={() => setIsQuoteModalOpen(true)}
                size="sm"
                className="bg-gradient-to-r from-shipblue-600 to-orange-500 hover:from-shipblue-700 hover:to-orange-600 text-white shadow-md hover:shadow-lg transition-all duration-300 px-6"
              >
                Get Quote
              </Button>
            </div>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="lg:hidden p-3 rounded-lg hover:bg-gray-100 transition-colors duration-200 touch-manipulation focus:outline-none focus:ring-2 focus:ring-shipblue-500 focus:ring-offset-2 min-w-[44px] min-h-[44px] flex items-center justify-center"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            aria-label={isMenuOpen ? "Close menu" : "Open menu"}
            aria-expanded={isMenuOpen}
            aria-controls="mobile-menu"
          >
            {isMenuOpen ? (
              <X className="h-6 w-6 text-gray-700" />
            ) : (
              <Menu className="h-6 w-6 text-gray-700" />
            )}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div
            id="mobile-menu"
            className="lg:hidden py-4 border-t border-gray-100 bg-white shadow-lg animate-fade-in"
            role="navigation"
            aria-label="Mobile navigation menu"
          >
            <div className="space-y-2 px-4">
              {navItems.map((item) => (
                <Link
                  key={item.href}
                  to={item.href}
                  onClick={() => setIsMenuOpen(false)}
                  className={`block px-4 py-4 rounded-xl font-medium transition-all duration-200 touch-manipulation min-h-[48px] flex items-center ${
                    location.pathname === item.href
                      ? "text-shipblue-600 bg-shipblue-50 border-l-4 border-shipblue-600"
                      : "text-gray-700 hover:text-shipblue-600 hover:bg-gray-50"
                  }`}
                  aria-current={
                    location.pathname === item.href ? "page" : undefined
                  }
                >
                  {item.label}
                </Link>
              ))}
            </div>
            <div className="space-y-3 mt-6 px-4">
              <Link to="/auth" onClick={() => setIsMenuOpen(false)}>
                <Button
                  variant="outline"
                  className="w-full border-shipblue-600 text-shipblue-600 hover:bg-shipblue-600 hover:text-white transition-all duration-300 py-4 touch-manipulation"
                >
                  Login / Sign Up
                </Button>
              </Link>
              <Button
                onClick={() => {
                  setIsQuoteModalOpen(true);
                  setIsMenuOpen(false);
                }}
                className="w-full bg-gradient-to-r from-shipblue-600 to-orange-500 hover:from-shipblue-700 hover:to-orange-600 text-white shadow-md py-4 touch-manipulation"
              >
                Get Quote
              </Button>
            </div>
          </div>
        )}
      </div>

      <GetQuoteModal
        open={isQuoteModalOpen}
        onOpenChange={setIsQuoteModalOpen}
      />
    </nav>
  );
}
