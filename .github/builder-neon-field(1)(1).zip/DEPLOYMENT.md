# ShipNexa.it Deployment Guide

Your professional logistics website is ready for deployment! Choose the option that best fits your needs.

## 🚀 Option 1: Netlify Deployment (Recommended)

### Quick Deploy from GitHub (5 minutes)

1. **Connect to Netlify:**

   - Go to [netlify.com](https://netlify.com) and sign up with your GitHub account
   - Click "Add new site" → "Import an existing project"
   - Connect your GitHub account and select the `ARSTRA/builder-neon-field` repository
   - Choose the `swoosh-forge` branch

2. **Configure Build Settings:**

   - Build command: `npm run build`
   - Publish directory: `dist/spa`
   - Node version: `18`
   - Click "Deploy site"

3. **Custom Domain Setup:**
   - In Netlify dashboard, go to "Domain settings"
   - Click "Add custom domain" and enter your Namecheap domain
   - Follow the DNS configuration instructions
   - Your site will be live with HTTPS automatically!

### Benefits:

- ✅ Free hosting with custom domain
- ✅ Automatic deployments from GitHub
- ✅ Free SSL certificate
- ✅ Global CDN
- ✅ Form handling for contact forms

---

## 🔧 Option 2: Build for Traditional Hosting (Namecheap/cPanel)

### Step 1: Build the Project

```bash
# Install dependencies
npm install

# Create production build
npm run build
```

### Step 2: Upload to Your Host

1. **Locate the build files:**

   - Built files will be in the `dist/spa` folder
   - This contains all static HTML, CSS, and JS files

2. **Upload via cPanel File Manager:**

   - Log into your Namecheap cPanel
   - Open File Manager
   - Navigate to `public_html` (or your domain folder)
   - Upload all contents from `dist/spa` folder
   - Extract/unzip if needed

3. **Configure URL Rewriting:**
   - Create `.htaccess` file in your domain root:

```apache
# React Router SPA Configuration
<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteBase /

  # Handle Angular and Vue.js router
  RewriteRule ^index\.html$ - [L]
  RewriteCond %{REQUEST_FILENAME} !-f
  RewriteCond %{REQUEST_FILENAME} !-d
  RewriteRule . /index.html [L]
</IfModule>

# Security Headers
<IfModule mod_headers.c>
  Header always set X-Frame-Options DENY
  Header always set X-Content-Type-Options nosniff
  Header always set Referrer-Policy "strict-origin-when-cross-origin"
</IfModule>

# Cache optimization
<IfModule mod_expires.c>
  ExpiresActive on
  ExpiresByType text/css "access plus 1 year"
  ExpiresByType application/javascript "access plus 1 year"
  ExpiresByType image/png "access plus 1 year"
  ExpiresByType image/jpg "access plus 1 year"
  ExpiresByType image/jpeg "access plus 1 year"
</IfModule>
```

---

## 📦 Option 3: GitHub Pages (Free Alternative)

### Automated GitHub Pages Deployment

1. **Enable GitHub Pages:**

   - Go to your repository settings
   - Scroll to "Pages" section
   - Select "GitHub Actions" as source

2. **Create deployment workflow:**

   - The workflow file will be created automatically
   - Every push to `main` branch will trigger deployment

3. **Custom Domain (Optional):**
   - In Pages settings, add your custom domain
   - Configure DNS in Namecheap to point to GitHub Pages

---

## 🌐 Option 4: Vercel Deployment

### Quick Deploy:

1. **Import Project:**

   - Go to [vercel.com](https://vercel.com)
   - Click "New Project" → Import from GitHub
   - Select your repository

2. **Configure:**
   - Build command: `npm run build`
   - Output directory: `dist/spa`
   - Deploy!

---

## 🔗 DNS Configuration for Custom Domain

### For Namecheap Domain:

1. **Log into Namecheap account**
2. **Go to Domain List → Manage**
3. **Advanced DNS Tab**

#### For Netlify:

- Add CNAME record: `www` → `your-netlify-site.netlify.app`
- Add A record: `@` → Netlify's IP (provided in dashboard)

#### For Vercel:

- Add CNAME record: `www` → `your-project.vercel.app`
- Add A record: `@` → `76.76.19.61`

#### For GitHub Pages:

- Add CNAME record: `www` → `yourusername.github.io`
- Add A records for `@`:
  - `185.199.108.153`
  - `185.199.109.153`
  - `185.199.110.153`
  - `185.199.111.153`

---

## 📋 Pre-Deployment Checklist

- [ ] Test all pages work correctly
- [ ] Verify mobile responsiveness
- [ ] Check all links and navigation
- [ ] Test contact forms
- [ ] Optimize images for web
- [ ] Configure analytics (Google Analytics, etc.)
- [ ] Set up error monitoring
- [ ] Test on different browsers

---

## 🚨 Troubleshooting

### Common Issues:

1. **404 errors on page refresh:**

   - Add proper routing configuration (`.htaccess` or platform-specific redirects)

2. **Images not loading:**

   - Check image paths and ensure they're in the build output
   - Verify image URLs are relative or use proper CDN paths

3. **CSS/JS not loading:**

   - Clear browser cache
   - Check build output includes all assets

4. **Contact forms not working:**
   - Configure form handling service (Netlify Forms, Formspree, etc.)

---

## 🎯 Recommended Choice

**For most users: Choose Netlify**

- Easiest setup with your existing GitHub repository
- Free hosting with custom domain
- Automatic deployments
- Built-in form handling
- Global CDN and SSL included

Your ShipNexa.it website is production-ready and will look professional on any of these platforms!
